"""
Utility modules for the phishing detection tool.
"""
